package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Servlet extends HttpServlet {
	
    public Servlet() {
    }
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	}

	 String technologies[] = {"Java","Python","Html-CSS-Javascript"};
	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		boolean isFound = false;
		
		// Read the paramater from Index page
		String technology = request.getParameter("technology");
		String city= request.getParameter("city");
		
		// code to validate technology 
		
		for (String tech:technologies) {
			if(technology.equalsIgnoreCase(tech))
			{
				
				// bind the technology with request scope
				request.setAttribute("technology", technology);
				request.setAttribute("city", city);
				// response.sendRedirect("MyServlet2"); // new req & resp 
				
				
				request.getRequestDispatcher("Servlet2").forward(request, response);
				isFound = true;
				break;
			}
		}//end for
		
		
		// in case of not validate 
		if(isFound == false)
		{
			out.print("Technology Not In The List");
		}
	
	
	}

}
