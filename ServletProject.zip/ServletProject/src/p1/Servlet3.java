package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Servlet3 extends HttpServlet {

    public Servlet3() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	
		
		List<String> jobs = (List<String>)request.getAttribute("jobs");
		String technologyName = (String)request.getAttribute("technology");
		String city= (String)request.getAttribute("city");
		
		out.print("Technology "+technologyName);
		out.print("<br/>");
		out.print("City "+city);
		out.print("<br/>");
		out.print("Jobs Available- "+jobs);
	}

}
