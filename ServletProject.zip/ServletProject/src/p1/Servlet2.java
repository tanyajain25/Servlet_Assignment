package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet2
 */
public class Servlet2 extends HttpServlet {
	
    public Servlet2() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		List<String> jobs = new ArrayList<String>();
		
		String technology = (String)request.getAttribute("technology");
		String city = (String)request.getAttribute("city");
		
		System.out.println(" servlet 2 "+technology);
		System.out.println(" servlet 2 "+city);
		out.print("<br/> Technology From Servlet 1 "+technology);
		out.print("<br/> City From Servlet 1 "+city);
		
		if(city.equalsIgnoreCase("New Delhi") && technology.equalsIgnoreCase("Java")) 
		{
			jobs.add("Java Developer");
			jobs.add("Full Stack Developer");
			jobs.add("Sr.Java Developer");
			
		}
		else if(city.equalsIgnoreCase("New Delhi") && technology.equalsIgnoreCase("Python")) 
		{
			jobs.add("Python Developer - Django Framework");
			jobs.add("Backend Developer - Python/django Stack");
			
		}
		else if(city.equalsIgnoreCase("New Delhi") && technology.equalsIgnoreCase("Html-CSS-Javascript")) 
		{
			jobs.add("AngularJS Developer - Javascript/ Html/ CSS");
			jobs.add("Frontend Web Developer - UI Platform - Html/ CSS");
			jobs.add("UI & HTML Developer");
			
			
		}
		else if(city.equalsIgnoreCase("Noida") && technology.equalsIgnoreCase("Java")) 
		{
			jobs.add("Java Developer - J2ee / Spring / Hibernate");
			jobs.add("Sr.Java Developer");
			
			
		}
		else if(city.equalsIgnoreCase("Noida") && technology.equalsIgnoreCase("Python")) 
		{
			jobs.add("Python Developer - Django Framework");
			jobs.add("Data Scientist - Python/ R/sql/machine Learning/spark/scala");
			
			
		}
		else if(city.equalsIgnoreCase("Noida") && technology.equalsIgnoreCase("Html-CSS-Javascript")) 
		{
			jobs.add("AngularJS Developer - Javascript/ Html/ CSS");
			jobs.add("Frontend Web Developer - UI Platform - Html/ CSS");
			
		}
		else if(city.equalsIgnoreCase("Greater Noida") && technology.equalsIgnoreCase("Java")) 
		{
			jobs.add("Java Developer");
			jobs.add("Full Stack Developer");
			jobs.add("Sr.Java Developer");
			
			
		}
		else if(city.equalsIgnoreCase("Greater Noida") && technology.equalsIgnoreCase("Python")) 
		{
			jobs.add("Python Developer - Django Framework");
			jobs.add("Data Scientist - Python/ R/sql/machine Learning/spark/scala");
			jobs.add("Backend Developer - Python/django Stack");
		}
		else if (city.equalsIgnoreCase("Greater Noida") && technology.equalsIgnoreCase("Html-CSS-Javascript")) 
		{
			jobs.add("AngularJS Developer - Javascript/ Html/ CSS");
			jobs.add("Frontend Web Developer - UI Platform - Html/ CSS");
			jobs.add("UI & HTML Developer");
			
		}
		
		request.setAttribute("jobs", jobs);
		
		request.getRequestDispatcher("Servlet3").forward(request, response);
		
	}

}
